<?php include('header.php'); ?>
			<!----- Contact ----->
			<div class="Contact">
				<!----- header-section ---->
				<div class="header-section">
					<div class="container">
						<h1>Videos</h1>
					</div>
				</div>
				<!----- header-section ---->
				<!----- hosting-grids ----->
				<div class="contact-grids">
					<div class="container">

						<div class="contact-bottom-grids">

							<div class="contact-bottom-grid">
								<div class="domain-grids">
                            					<div class="domain-grid text-center">
                            						<div class="container">

                            								<div class="domain-grid-right">
                            									<h2><a href="#">Videos</a></h2>
                            									<span>Performances by En Route Thursdays</span>
                            									<div class="clearfix"> </div>
                            								</div>

                            							<div class="clearfix"> </div>
                            						</div>
                            					</div>
                            					<div class="domain-grid text-center">
                            						<div class="container">
                            								 <center>
                                                                <div class="domain-grid-left">
                                                                    <div class="flex-video">
                                                                        <iframe width="560" height="315" src="https://www.youtube.com/embed/t10ALEpwG8A" frameborder="0" allowfullscreen></iframe>
                            								        </div>
                                                                </div>
                                                            </center>
                            							<div class="clearfix"> </div>
                            						</div>
                            					</div>
                            					<div class="domain-grid text-center">
                            						<div class="container">
                            								 <center>
                                                                <div class="domain-grid-left">
                                                                    <div class="flex-video">
                                                                        <iframe width="560" height="315" src="https://www.youtube.com/embed/rUuoQxwluXA" frameborder="0" allowfullscreen></iframe>
                            								        </div>
                                                                </div>
                                                            </center>

                            							<div class="clearfix"> </div>
                            						</div>
                            					</div>
                                                <div class="domain-grid text-center">
                                                    <div class="container">
                                                    <center>
                                                        <div class="domain-grid-left">
                                                            <div class="flex-video">
                                                              <iframe width="560" height="315" src="https://www.youtube.com/embed/Q4K88scnVtc" frameborder="0" allowfullscreen></iframe>
                                                            </div>
                                                        </div>
                                                    </center>
                                                        <div class="clearfix"> </div>
                                                    </div>
                                                </div>
                                                <div class="domain-grid text-center">
                                                    <div class="container">
                                                    <center>
                                                        <div class="domain-grid-left">
                                                            <div class="flex-video">
                                                                <iframe width="560" height="315" src="https://www.youtube.com/embed/hOVzpoeFMyo" frameborder="0" allowfullscreen></iframe>
                                                            </div>
                                                        </div>
                                                    </center>
                                                        <div class="clearfix"> </div>
                                                    </div>
                                                </div>
                                                <div class="domain-grid text-center">
                                                    <div class="container">
                                                     <center>
                                                        <div class="domain-grid-left">
                                                            <div class="flex-video">
                                                              <iframe width="560" height="315" src="https://www.youtube.com/embed/n8BHnkA5wdQ" frameborder="0" allowfullscreen></iframe>
                                                            </div>
                                                        </div>
                                                    </center>
                                                    <div class="clearfix"> </div>
                                                    </div>
                                                </div>

                            				</div>
							</div>
							<div class="clearfix"> </div>
						</div>
					</div>
				</div>
				<!----- hosting-grids ----->
			</div>
			<!----- About ----->
			
			<?php include('footer.php'); ?>